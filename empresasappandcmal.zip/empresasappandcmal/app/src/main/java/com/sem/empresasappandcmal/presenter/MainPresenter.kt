package com.sem.empresasappandcmal.presenter

import androidx.fragment.app.Fragment

interface MainPresenter {
    fun deleteDatabase()
}