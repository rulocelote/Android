package com.sem.empresasappandcmal.presenter.splash

interface SplashPresenter {
    fun comprobarUsuarios()
}