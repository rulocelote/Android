# EmpresasAppANDCMAL

Proyecto en android para hacer la app de empresas, Equipo 5, Moises Castrejón Méndez y Carlos Alberto Arteaga Lira. 