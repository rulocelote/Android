package com.sem.empresasappandcmal.model.login

interface LoginModel {
    fun validaLogin(numEmpleado:String, password:String)
}