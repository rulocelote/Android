package com.sem.empresasappandcmal.utils

object Constants{
    val URL_BASE = "http://192.168.43.182:8080/appempresarial-4/"
    val DATA_BASE = "UsuariosDB"
    val IDE_ONE = "1"
    val IDE_TWO = "2"
    val IDE_THREE = "3"
    val IDE_FOUR = "4"
    val IDE_FIVE = "5"
}