package com.sem.empresasappandcmal.view.splash

interface SplashView {
    fun intentLogin()
    fun intentMain(numEmpleado:String)
}