package com.example.reto3

import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bottomNavigationView = bottom_navigation as BottomNavigationView
        bottomNavigationView.setOnNavigationItemSelectedListener(object : BottomNavigationView.OnNavigationItemSelectedListener {
            override fun onNavigationItemSelected(item: MenuItem): Boolean {
                when (item.getItemId()) {
                    R.id.action_recents -> Toast.makeText(this@MainActivity, "Recents", Toast.LENGTH_SHORT).show()
                    R.id.action_favorites -> Toast.makeText(this@MainActivity, "Favorites", Toast.LENGTH_SHORT).show()
                    R.id.action_nearby -> Toast.makeText(this@MainActivity, "Nearby", Toast.LENGTH_SHORT).show()
                    R.id.action_prueba -> Toast.makeText(this@MainActivity, "Prueba", Toast.LENGTH_SHORT).show()
                }
                return true
            }
        })

    }
}
