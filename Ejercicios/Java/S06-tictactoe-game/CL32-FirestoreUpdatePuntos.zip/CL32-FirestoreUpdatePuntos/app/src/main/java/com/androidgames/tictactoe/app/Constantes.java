package com.androidgames.tictactoe.app;

public class Constantes {
    public static final String EXTRA_JUGADA_ID = "jugadaId";
}
